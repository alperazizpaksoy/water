﻿using System;

namespace ConsoleApp5
{
    internal class Program
    {
        public static int harita(int[] yukseklik) //Burda haritanin icinde tutucagi su miktarini hesaplayan bir fonksiyon var ve bu fonksiyon yukseklik dizisi ile calisiyor.
        {   //sol degiskeni cukurun baslangic noktasi olarak belirleniyor , sag da son indeks olarak bakarsak 5 sutunlu yerde 4.indeks son olcagindan dolayi lenght-1 
            int sol = 0, sag = yukseklik.Length - 1, solMax = 0, sagMax = 0, miktar = 0;
            //Cukurdaki en sol ve en sagin en yuksek noktalarini bulup sonra diger noktalarla karsilastirarak ne kadar su alabilcegini hesapliyor.
            while (sol <= sag)
            {   
                if (yukseklik[sol] <= yukseklik[sag])
                {
                    if (yukseklik[sol] >= solMax)
                    {   
                        solMax = yukseklik[sol];
                    }
                    else
                    {
                        miktar += solMax - yukseklik[sol];
                    }
                    sol++;
                }
                else
                {
                    if (yukseklik[sag] >= sagMax)
                    {
                        sagMax = yukseklik[sag];
                    }
                    else
                    {
                        miktar += sagMax - yukseklik[sag];
                    }
                    sag--;
                }
            }

            return miktar;
        }

        static void Main(string[] args)
        {
            Console.Write("Suyun tutulcagi haritanin yukseklik dizisinin boyutunu girin: ");
            int n = Convert.ToInt32(Console.ReadLine());

            int[] yukseklik = new int[n];
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Dizinin {i + 1}. elemanı girin: ");
                yukseklik[i] = Convert.ToInt32(Console.ReadLine());
            }

            int sonuc = harita(yukseklik);
            Console.WriteLine("Toplam tutabilcegi su miktarı: " + sonuc);



        }
    }
}
